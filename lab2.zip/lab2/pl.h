#ifndef PL_H_INCLUDED
#define PL_H_INCLUDED

typedef struct
{
    float x;
    float y;
    float dx;
    float dy;

} Hero;

void Hero_Init(Hero *obj, float x1, float y1, float dx1, float dy1);
void Reflect (float *da, float *a, Hero *obj, bool cond, float wall);
void Hero_Move(Hero *obj,bool st);
void Hero_Show();


#endif // PL_H_INCLUDED
