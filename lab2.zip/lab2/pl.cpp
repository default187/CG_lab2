#include <gl/gl.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <malloc.h>
#include "tExtur.h"

typedef struct
{
    float x;
    float y;
    float dx;
    float dy;

} Hero;

float gravity=0.5;
float speed=3.5;
float currentframe;

bool directional;

void Hero_Init(Hero *obj, float x1, float y1, float dx1, float dy1)
{
    obj->x=x1;
    obj->y=y1;
    obj->dx=dx1;
    obj->dy=dy1;
}

void Reflect (float *da, float *a,Hero *obj, BOOL cond, float wall)
{
    if (!cond) return;
    *da*=-0; // ���� -0,1
    *a=wall;
}

void Hero_Move(Hero *obj,bool st)
{
    obj->y+=obj->dy;
    Reflect(&obj->dy,&obj->y, obj, obj->y<0,0);
  //  Reflect(&obj->dx,&obj->x, &obj, obj->x<200, 200);
   // Reflect(&obj->dx,&obj->x, &obj, obj->x>width-chSiX-200, width-chSiX-200);
    obj->dy-=gravity;
    if (GetKeyState(VK_LEFT)<0 && st==1)
    {
        currentframe+=0.15;
        obj->dx-=speed;
        obj->x+=obj->dx;
        obj->dx=0;
        if (currentframe>8) currentframe-=7;
        directional=1;
        //cout << currentframe <<';'<< directional <<';' << obj->x << ';' << obj->y << endl;
    }

    if (GetKeyState(VK_RIGHT)<0 && st==1)
    {
        currentframe+=0.15;
        obj->dx+=speed;
        obj->x+=obj->dx;
        obj->dx=0;
        if (currentframe>8) currentframe-=7;
        directional=0;
        //cout << currentframe <<';'<< directional <<';' << obj->x << ';' << obj->y << endl;

    }
    if (GetKeyState(VK_UP)<0 && (obj->y<410) && st==1)
    {
        obj->dy =speed*1.6;
        obj->y+=obj->dy;
    }
}
